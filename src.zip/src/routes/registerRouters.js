
const express = require('express');

const registermodel = require('../models/registerModel');

const registerRouter = express.Router()

registerRouter.post('/',async(req,res)=>{
try {
    const data ={
        email :req.body.email,
        password:req.body.password,
        conformpassword:req.body.conformpassword
    }
    
    const oldemail = await registermodel.findOne({ email :req.body.email})

    if(oldemail){
        return res.status(400).json({
            success: false,
            error: true,
            message: "This email already exists",
            data: oldemail
        })
    }
    const register = await registermodel(data).save();
    console.log("old ====>",register);
    if(register){
        return res.status(200).json({
            success:true,
            error:false,
            message :"data added successfuly",
            data:register
        })
    } else {
        return res.status(400).json({
            success: false,
            error: true,
            message: "registation failed",
        })
    }
    
} catch (error) {
    return res.status(500).json({
        success:false,
        error:true,
        message:"something went wrong"
    })
}
});
module.exports= registerRouter