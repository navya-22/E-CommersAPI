 const express = require('express')
const productoffermodel = require('../models/productofferModel')

 const productofferRouter = express.Router()

 productofferRouter.post('/',async(req,res)=>{
    try {
        const data ={
            // image :{type : String, require :true},
            name : req.body.name,
            details:req.body.details,
            price:req.body.price,
            oldprice:req.body.oldprice,
            offer:req.body.price,
            rate:req.body.rate
        }
   const oldname = await productoffermodel.findOne({name:req.body.name})
   if(oldname){
    return res.status(400).json({
        success: false,
        error :true,
        message : "this name already exist",
        data : oldname
    })
   }
   const offer = await productoffermodel(data).save()
   if (offer){
    return res.status(200).json({
        success :true,
        error :false,
        message:"data added successfuly",
        data:offer
    })
   }

    } catch (error) {
       return res.status(500).json({
        success  :false,
        error:true,
        message : "something went wrong "
       }) 
    }
 })
 module.exports = productofferRouter