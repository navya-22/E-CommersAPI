const express = require('express')
const shoppagemodel = require('../models/shopPageModel')
const shoppageRouter= express.Router()

shoppageRouter.post('/view-product',async(req,res)=>{
    try {
        const data = {
     // Image :,
     name :req.body.name,
     producttype :req.body.producttype,
     rate:req.body.rate,
     oldprice:req.body.oldprice,
     price:req.body.price,
     offer:req.body.offer,
     detail:req.body.detail,
        }
const oldname = await shoppagemodel.findOne({name:req.body.name})
  if(oldname){
    return res.status(400).json({
        success:false,
        error:true,
        message:"name already exists",
        data:oldname
    })
  }
const page = shoppagemodel(data).save()
if(page){
    return res.status(200).json({
        success:true,
        error:false,
        message:'data added successfuly',
        data:page
    })
}

    } catch (error) {
        return res.status(500).json({
            success:false,
            error:true,
            message:"something went wrong"
        })
    }
})

module.exports = shoppageRouter