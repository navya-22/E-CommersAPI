const express = require ('express')

const multer = require('multer')
const cloudinary = require('cloudinary').v2
const{CloudinaryStorage} = require ('multer-storage-cloudinary')
const productmodel = require('../models/.productmodel')
const productRouter = express.Router()
cloudinary.config({
  cloud_name: 'dtg6vfgil',
  api_key: '858789642953189',
  api_secret: 'Pf7YTZQgZBRa3mV_ueijit0B9P4'
});

const imageStorage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: {
    folder: 'images'
  },
});

const uploadImage = multer({ storage: imageStorage });



productRouter.post('/save-product', uploadImage.array('image',1), async (req, res) => {
  try {
    console.log(req);

    const data = {
      image: req.file ? req.file.map((file) => file.path) : null,
      name: req.body.name,
      details: req.body.details,
      price: req.body.dprice,
      rate: req.body.rate,
    };

    const oldname = await productmodel.findOne({ name: req.body.name });
    if (oldname) {
      return res.status(400).json({
        success: false,
        error: true,
        message: "This product name already exists",
        data: oldname
      });
    }

    const product = await productmodel(data).save();
    if (product) {
      return res.status(200).json({
        success: true,
        error: false,
        message: "Data added successfully",
        data: dress
      });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      error: true,
      message: "Something went wrong"
    });
  }
});

module.exports =productRouter