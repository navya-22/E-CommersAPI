const express = require('express')
const loginmodel = require('../models/loginModel')
const registermodel = require('../models/registerModel')
const loginRouter = express.Router()

loginRouter.post('/',async(req,res)=>{
    try {
        const data ={
            email:req.body.email,
            password:req.body.password
        }
        const oldemail = await registermodel.findOne({email :req.body.email})
        if(!oldemail){
            return  res.status(400).json({
                success:false,
                error:true,
                message:"email is not found",
                
            })
        }
        const oldpassword =await registermodel.findOne({password:req.body.password})
        if(!oldpassword){
            return res.status(400).json({
                success:false,
                error:true,
                message:"there is no matching password"
            })
        }
        const login = await loginmodel(data).save()
      if(login){
        return res.status(200).json({
            success:true,
            error:false,
            message :"data added successfuly",
            data:login  
        })
      }else{
        return res.status(400).json({
            success:false,
            error:true,
            message:"login failed"
        })
      }

    } catch (error) {
        return res.status(500).json({
            success:false,
            error:true,
            message:"something went wrong"
        })
    }
})

module.exports = loginRouter