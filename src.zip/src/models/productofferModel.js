const mongoose = require("mongoose")
const offerSchema = new mongoose.Schema({
    // image :{type : String, require :true},
   name : {type : String,require :true},
   details:{type: String,require :true},
   price:{type:Number,require:true},
   oldprice:{type:Number,require:true},
   offer:{type:String ,require :true},
   rate:{type :String,require:true}
})

var productoffermodel = mongoose.model('offer_tb',offerSchema);

module.exports = productoffermodel