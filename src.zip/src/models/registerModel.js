const mongoose = require ("mongoose")
 
const registerSchema = new mongoose.Schema({
    email :{type:String , require:true},
    password:{type:String, require:true},
    conformpassword:{type:String,require:true}
});

var registermodel = mongoose.model('register_tb',registerSchema);
module.exports =registermodel