const mongoose =require("mongoose")

const productSchema = new mongoose.Schema({
   image :{type : String, require :true},
   name : {type : String,require :true},
   details:{type: String,require :true},
   price:{type:Number,require:true},
   rate:{type :String,require:true}
})

var productmodel = mongoose.model('dress_tb',productSchema);
module.exports = productmodel