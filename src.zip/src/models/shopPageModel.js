const mongoose = require("mongoose")

const shoppageSchema = {
    // Image :{type : String,require:true},
    name :{type:String , require:true},
    producttype :{type :String , require:true},
    rate:{type:String,require:true},
    oldprice:{type:Number,require :true},
    price:{type:Number,require:true},
    offer:{type:String,require:true},
    detail:{type:String,require:true},
}

var shoppagemodel= mongoose.model('shoppage_tb',shoppageSchema);
module.exports = shoppagemodel