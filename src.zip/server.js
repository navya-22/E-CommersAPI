// import library
const express = require('express')
const mongoose = require("mongoose");
const cors= require ('cors')
// const bodyParser = require('body-parser');
const productRouter = require('./src/routes/productRouters');
const registerRouter = require('./src/routes/registerRouters');
const loginRouter = require('./src/routes/loginRouter');
const productofferRouter = require('./src/routes/productofferRouter');
const shoppageRouter = require('./src/routes/shopPageRouter');
const app = express()
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({extended: true}))

app.use('/product',productRouter)
app.use('/register',registerRouter)
app.use('/login',loginRouter)
app.use('/offer',productofferRouter)
app.use('/shoppage',shoppageRouter)
//connect to mongoo
mongoose.connect("mongodb+srv://navyamanojkk2004:Rzpf3fXLc61ZG20d@cluster0.lti8qwe.mongodb.net/e-commers").then(()=>{
    app.listen(2020 ,()=>{
      console.log('server running on 2020 http://localhost:2020');
    })

})